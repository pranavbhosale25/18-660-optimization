from jaxbo.labs.core import Problem
from jaxbo.spaces import MixedSpace

NAMES: tuple[str, str, str, str, str]
RUNTIME_API_VERSION: int
__version__: str

def make_problem(
    name: str,
    instance: int = ...,
    *,
    split: str = ...,
    budget: float | None = ...,
) -> Problem: ...

def pipeline_space() -> MixedSpace: ...
