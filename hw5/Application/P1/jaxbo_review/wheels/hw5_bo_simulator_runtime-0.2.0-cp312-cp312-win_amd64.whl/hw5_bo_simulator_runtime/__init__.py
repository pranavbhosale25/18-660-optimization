"""Public interface for the compiled HW5 simulator runtime."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from jaxbo.labs.core import Problem
    from jaxbo.spaces import MixedSpace


NAMES = ("coating", "pipeline", "production", "materials", "controller")
RUNTIME_API_VERSION = 1
__version__ = "0.2.0"


def make_problem(
    name: str,
    instance: int = 0,
    *,
    split: str = "development",
    budget: float | None = None,
) -> Problem:
    """Construct one local development problem using the native runtime."""

    # Import lazily so this package can be inspected and audited independently
    # of the matching public jaxbo package. It also avoids a circular import
    # while jaxbo.labs is initializing its simulator facade.
    from ._simulators import make_problem as compiled_make_problem

    return compiled_make_problem(
        name,
        instance,
        split=split,
        budget=budget,
    )


def pipeline_space() -> MixedSpace:
    """Return the public mixed decision space used by the pipeline problem."""

    from ._simulators import pipeline_space as compiled_pipeline_space

    return compiled_pipeline_space()


__all__ = ["NAMES", "RUNTIME_API_VERSION", "make_problem", "pipeline_space"]
