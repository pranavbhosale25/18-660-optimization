"""Public interface for the compiled HW1 optimizer runtime."""

from .api import PreparedOptimizer, minimize, prepare_minimize
from .benchmarking import BenchmarkMode, synchronize_result
from .types import (
    AdamOptions,
    BaseOptions,
    CGBetaMethod,
    CGLineSearch,
    CGOptions,
    IterationRecord,
    LBFGSOptions,
    Method,
    NewtonOptions,
    OptimizeResult,
    Status,
    TrustRegionOptions,
    WorkStats,
)

__all__ = [
    "minimize",
    "prepare_minimize",
    "synchronize_result",
    "PreparedOptimizer",
    "AdamOptions",
    "BaseOptions",
    "BenchmarkMode",
    "CGBetaMethod",
    "CGLineSearch",
    "CGOptions",
    "IterationRecord",
    "LBFGSOptions",
    "Method",
    "NewtonOptions",
    "OptimizeResult",
    "Status",
    "TrustRegionOptions",
    "WorkStats",
]

__version__ = "0.1.3"
